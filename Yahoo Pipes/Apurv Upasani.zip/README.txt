################################ README ################################################

Homework 9

Name: Apurv Upasani	     USC ID: 4839-3102-30	     Email: aupasani@usc.edu

########################################################################################

“I, _Apurv Upasani   , declare that the submitted work is original and adheres to all University policies and acknowledge the consequences that may result from a violation of those rules”

1)	My mashup application is used to display latest news about art events, exhibitions, shows etc from round the world. I collect RSS feeds from various news sites from round the world to collate the art information related to any form of art. 

2)	For my data sources, I have chosen major newspapers which provide information on arts.  This enables me to keep my website updated as these newspapers update their RSS feeds regularly. I have also used google.news module from YQL to search for arts and statues in Google News domain.
Data Sources used:
1)	Reuters News -  http://feeds.reuters.com/news/artsculture
2)	New York Times -  http://rss.nytimes.com/services/xml/rss/nyt/Arts.xml
3)	Daily Telegraph UK - http://www.telegraph.co.uk/culture/art/art-news/rss
4)	Museum of Modern Art , New York -  http://www.moma.org/feeds/today_at_moma.rss
5)	google.news – YQL module

3)	Following is my YQL query
	
	select * from google.news where q = "art statue painting" 
    
	It returns a result set which is a combination of news related to art, statues or paintings from Google API. I have used the following module for following reasons:
    i)	Easy to use API. No API Keys required for authentication 
    ii)	Only 1 mandatory variable q which is used to specify query

	One small issue with this API is that it returns a very low number of feeds back to the application. I use RSS builder to generate the RSS feed from the returned data response and integrate it with the existing pool of news feeds.

4) Link to Yahoo Pipe

   https://pipes.yahoo.com/pipes/pipe.info?_id=367a681ba851b421743a6939320a2fa7	
