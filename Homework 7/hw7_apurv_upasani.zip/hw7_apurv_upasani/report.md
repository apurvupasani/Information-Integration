## Hw7Input.json

### PyTransforms

### Semantic Types
| Column | Property | Class |
|  ----- | -------- | ----- |
| _ArtistBirthDate_ | `schema:birthDate` | `schema:Person1`|
| _Artist_BirthPlace_ | `schema:addressRegion` | `schema:PostalAddress2`|
| _Artist_DeathPlace_ | `schema:addressRegion` | `schema:PostalAddress3`|
| _Artist_Death_Date_ | `schema:deathDate` | `schema:Person1`|
| _Artist_First_Name_ | `schema:givenName` | `schema:Person1`|
| _Artist_Surname_ | `schema:familyName` | `schema:Person1`|
| _Painting_ArtistNo_ | `schema:serialNumber` | `schema:Person1`|
| _Painting_Artist_URI_ | `uri` | `schema:Person1`|
| _Painting_End_Date_ | `schema:endDate` | `schema:Painting1`|
| _Painting_Location_ | `schema:addressLocality` | `schema:PostalAddress1`|
| _Painting_Material_ | `dcterms:description` | `schema:Painting1`|
| _Painting_Name_ | `rdfs:label` | `schema:Painting1`|
| _Painting_No_ | `schema:serialNumber` | `schema:Painting1`|
| _Painting_Place_ | `schema:addressRegion` | `schema:PostalAddress1`|
| _Painting_Start_Date_ | `schema:startDate` | `schema:Painting1`|
| _Painting_URI_ | `uri` | `schema:Painting1`|
| _Painting_URL_ | `schema:image` | `schema:Painting1`|


### Links
| From | Property | To |
|  --- | -------- | ---|
| `schema:Painting1` | `schema:contentLocation` | `schema:Place1`|
| `schema:Painting1` | `schema:creator` | `schema:Person1`|
| `schema:Person1` | `schema:address` | `schema:PostalAddress2`|
| `schema:Person1` | `schema:address` | `schema:PostalAddress3`|
| `schema:Place1` | `schema:address` | `schema:PostalAddress1`|
