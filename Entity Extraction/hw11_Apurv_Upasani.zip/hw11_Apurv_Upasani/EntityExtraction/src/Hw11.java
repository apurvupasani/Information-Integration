
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.FileRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.openrdf.OpenRDFException;
import org.openrdf.model.Value;
import org.openrdf.query.BindingSet;
import org.openrdf.query.QueryLanguage;
import org.openrdf.query.TupleQuery;
import org.openrdf.query.TupleQueryResult;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.manager.RemoteRepositoryManager;
import org.openrdf.rio.RDFFormat;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

/** This class is used to perform named entity extraction and recognition. It takes the web page URL as input
 *  and prints the corresponding entities and URIs.
 * 
 * @author Apurv Upasani
 *
 */

public class Hw11 {

	//Declare member variables here
	private static final String CALAIS_URL = "http://api.opencalais.com/tag/rs/enrich";
    private File input,xmlOutput;
    private File output;
    private HttpClient client;

    /** This method sets XML params for OpenCalais to capture and send response. 
     *  It captures 3 mandatory parameters
     *  - License Key
     *  - Request format
     *  - Response format
     *  
     * @return PostMethod
     */
    private PostMethod createPostMethod() {

        PostMethod method = new PostMethod(CALAIS_URL);
        // Set mandatory parameters
        method.setRequestHeader("x-calais-licenseID", "xejg3c8j4awnng6chqk3r86r");
        // Set input content type
        method.setRequestHeader("Content-Type", "text/html; charset=UTF-8");
		// Set response/output format
        method.setRequestHeader("Accept", "xml/rdf");
                
        return method;
    }

    /** This method reads the input file ie. the html parsed and returns calls the post method
     *  to execute the opencalais web service. It stores the response in output file
     * 
     */
	private void run() {
		try {
            if (input.isFile()) 
            {
                postFile(input, createPostMethod());
            }
            else if (input.isDirectory()) 
            {
                System.out.println("working on all files in " + input.getAbsolutePath());
                
                for (File file : input.listFiles())
                {
                    if (file.isFile())
                        postFile(file, createPostMethod());
                    else
                        System.out.println("skipping "+file.getAbsolutePath());
                }
            }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/** This method performs the request using the POST parameters and calls saveResponse to parse the 
	 *  response string 
	 * 
	 * @param file
	 * @param method
	 */
    private void doRequest(File file, PostMethod method) {
        try {
            int returnCode = client.executeMethod(method);
            if (returnCode == HttpStatus.SC_NOT_IMPLEMENTED) {
                System.err.println("The Post method is not implemented by this URI");
                // still consume the response body
                method.getResponseBodyAsString();
            } else if (returnCode == HttpStatus.SC_OK) {
                System.out.println("File post succeeded: " + file);
                saveResponse(file, method);
            } else {
                System.err.println("File post failed: " + file);
                System.err.println("Got code: " + returnCode);
                System.err.println("response: "+method.getResponseBodyAsString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            method.releaseConnection();
        }
    }
    //End of method
    
    /** This method captures the response and stores the response in the output file for the storing
     *  in triple store
     *  
     * 
     */
    private void saveResponse(File file, PostMethod method) throws IOException {
        PrintWriter writer = null;
        File out= null;
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    method.getResponseBodyAsStream(), "UTF-8"));
            out = new File(output, file.getName() + ".rdf");
            //writer = new PrintWriter(new BufferedWriter(new FileWriter(out)));
            writer = new PrintWriter(out,"UTF-8");
            writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            String line;
            while ((line = reader.readLine()) != null) {
                writer.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) try {
            writer.close();
            xmlOutput = out;
            } catch (Exception ignored) {}
        }
    }

    /** This is used to invoke the OpenCalais API
     * 
     * @param file
     * @param method
     * @throws IOException
     */
    private void postFile(File file, PostMethod method) throws IOException {
        method.setRequestEntity(new FileRequestEntity(file, null));
        doRequest(file, method);
    }

    /**This method is used to fetch content of URL web page and stores the HTML in file
     * 
     * @param url
     * @param fileURL
     * @return
     * @throws Exception
     */
    private static File readArticle(String url, String fileURL) throws Exception
    {
    		File file = new File(fileURL);
            URL objURL = new URL(url);
            URLConnection conn = objURL.openConnection();
            FileWriter fw = new FileWriter(file);
            
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            
            String inputLine;
            while ((inputLine = in.readLine()) != null) 
                fw.write(inputLine);
            
            in.close();
            fw.close();
       
    	return file;
    }
    
    /** This function is used to populate the local repository with RDF file got from OpenCalais
     * 
     * @param file
     * @throws Exception
     */
    private void populateLocalRepository(File file) throws Exception
    {
    	String baseURI = "";
    	String serverUrl = "http://localhost:6655/openrdf-sesame";
		RemoteRepositoryManager manager = new RemoteRepositoryManager(serverUrl);
		manager.initialize();
    	Repository myRepository = manager.getRepository("Homework11");
    	try {
    	   RepositoryConnection con = myRepository.getConnection();
    	   try { 
    		  System.out.println(file.getAbsolutePath()); 
    	      con.add(file, baseURI, RDFFormat.RDFXML);
    	   }
    	   catch(Exception e)
    	   {
    		   e.printStackTrace();
    	   }
    	   finally {
    	      con.close();
    	      
    	   }
    	}
    	catch (Throwable e)
    	{
    		e.printStackTrace();
    	}
    }
    //End of method
    
    /** Static method to parse the value from the repository
     * 
     */
    private static String getValue(Value val)
	{
		if(val ==null)
			return "";
		else 
			return val.toString();
	}
    
    /** This is used to query the triple store and returns the appropriate entities from the triple
     *  store.
     * 
     * @throws Exception
     */
    private void fetchAndPrintTripleDetails() throws Exception
    {
    	String baseURI = "";
    	String serverUrl = "http://localhost:6655/openrdf-sesame";
		RemoteRepositoryManager manager = new RemoteRepositoryManager(serverUrl);
		manager.initialize();
    	Repository myRepository = manager.getRepository("Homework11");
    	RepositoryConnection con  = myRepository.getConnection();
    	
    	
    	StringBuffer sb = new StringBuffer();
    	
    	try
    	{
    	sb.append("PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>");
    	sb.append("PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>");
    	sb.append("PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>");
    	sb.append("select ?p ?q {");
    	sb.append("?p  <http://s.opencalais.com/1/pred/name> ?q .");
        sb.append("?p rdf:type <http://s.opencalais.com/1/type/em/e/XXXXXXXXX> . }");
        String query = sb.toString();
        
        String []arrEntities = new String[]{"Person","City","Organization"};
        
        for(String entity:arrEntities)
        {
        	System.out.println("\n");
        	
        	String queryTemp = query.replaceAll("XXXXXXXXX", entity);
        	TupleQuery tupleQuery = con.prepareTupleQuery(QueryLanguage.SPARQL, queryTemp);
        	TupleQueryResult result = tupleQuery.evaluate();
        	try
        	{
        	  while (result.hasNext())
        	  {
        		  BindingSet bindingSet = (BindingSet) result.next();
        		  System.out.println(entity+ " | " + getValue(bindingSet.getValue("p"))+" | "+ getValue(bindingSet.getValue("q")));
        		  
        	  }
        	}
        	  finally {
			      result.close();
			  }
        	  
        	  
        }
    	}
    	finally
    	{
    		con.close();
    	}
    }
    
    /** This is a main method which is used to invoke the page and store the queries in triple store
     *  This program stores the results in triple store and queries it appropriately to display the results in 
     *  tabular format. It takes one argument - The HTML path corresponding to the page to be cached and 
     *  searched
     * 
     * @param args
     */
    public static void main(String[] args) {
        
    	Hw11 httpClientPost = new Hw11();
        File input = null;
        
       try
       {
    	//Fetch html from url and copy to a local file
    	input = readArticle(args[0],"Input.txt");    
    	httpClientPost.input = input;
    	//Set the output local directory
        httpClientPost.output = new File(".");
        httpClientPost.client = new HttpClient();
        httpClientPost.client.getParams().setParameter("http.useragent", "Calais Rest Client");
        httpClientPost.run();

        //Read the output xml and load the stuff into the repository
        httpClientPost.populateLocalRepository(httpClientPost.xmlOutput);
        
        //Print triple details
        httpClientPost.fetchAndPrintTripleDetails();
       
       
       }
       catch(Throwable e)
       {
    	   e.printStackTrace();
       }
       finally
       {
    	   
       }
    }
    //End of method


}
